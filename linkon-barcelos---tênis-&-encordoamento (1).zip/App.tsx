import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Training } from './components/Training';
import { Stringing } from './components/Stringing';
import { Experience } from './components/Experience';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { GMBModal } from './components/GMBModal';
import { Reveal } from './components/Reveal';
import { ChevronUp } from 'lucide-react';

interface BallParticle {
  id: number;
  x: number;
  y: number;
}

export type TabId = 'inicio' | 'treinos' | 'encordoamento' | 'experiencia' | 'sobre' | 'contato';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabId>('inicio');
  const [isGMBModalOpen, setIsGMBModalOpen] = useState(false);
  const [particles, setParticles] = useState<BallParticle[]>([]);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const audioContext = useRef<AudioContext | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const playTennisInteractionSound = useCallback(() => {
    try {
      if (!audioContext.current) {
        audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioContext.current;
      if (ctx.state === 'suspended') ctx.resume();

      const now = ctx.currentTime;
      
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.08, now);
      masterGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      masterGain.connect(ctx.destination);

      const pockOsc = ctx.createOscillator();
      pockOsc.type = 'sine';
      pockOsc.frequency.setValueAtTime(650, now);
      pockOsc.frequency.exponentialRampToValueAtTime(150, now + 0.05);
      
      const pockGain = ctx.createGain();
      pockGain.gain.setValueAtTime(0.6, now);
      pockGain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      
      pockOsc.connect(pockGain);
      pockGain.connect(masterGain);

      const noiseBuffer = ctx.createBuffer(1, ctx.sampleRate * 0.05, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < noiseBuffer.length; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      
      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      
      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.setValueAtTime(2000, now);
      
      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.15, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
      
      noiseSource.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(masterGain);

      pockOsc.start(now);
      noiseSource.start(now);
      pockOsc.stop(now + 0.2);
    } catch (e) {
      console.warn("Audio playback failed", e);
    }
  }, []);

  const spawnBall = useCallback((x: number, y: number) => {
    playTennisInteractionSound();
    const id = Date.now() + Math.random();
    setParticles((prev) => [...prev, { id, x, y }]);
    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => p.id !== id));
    }, 1600);
  }, [playTennisInteractionSound]);

  useEffect(() => {
    const handleInteraction = (e: MouseEvent | TouchEvent) => {
      let x, y;
      if ('touches' in e) {
        if (e.touches.length > 0) {
          x = e.touches[0].clientX;
          y = e.touches[0].clientY;
        } else {
          return;
        }
      } else {
        x = (e as MouseEvent).clientX;
        y = (e as MouseEvent).clientY;
      }
      spawnBall(x, y);
    };

    window.addEventListener('mousedown', handleInteraction);
    window.addEventListener('touchstart', handleInteraction, { passive: true });

    return () => {
      window.removeEventListener('mousedown', handleInteraction);
      window.removeEventListener('touchstart', handleInteraction);
    };
  }, [spawnBall]);

  const changeTab = (tab: TabId) => {
    if (tab === activeTab) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    
    setIsTransitioning(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    setTimeout(() => {
      setActiveTab(tab);
      setIsTransitioning(false);
    }, 300);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'inicio':
        return (
          <div key="inicio">
            <Hero 
              onTrainingClick={() => changeTab('treinos')} 
              onStringingClick={() => changeTab('encordoamento')}
            />
          </div>
        );
      case 'treinos':
        return (
          <div key="treinos" className="py-24 bg-gray-50 min-h-[70vh]">
            <Training />
          </div>
        );
      case 'encordoamento':
        return <div key="encordoamento" className="py-20 bg-white min-h-[70vh]"><Stringing onContactClick={() => changeTab('contato')} /></div>;
      case 'experiencia':
        return <div key="experiencia" className="py-20 bg-gray-50 min-h-[70vh]"><Experience /></div>;
      case 'sobre':
        return <div key="sobre" className="py-20 bg-white min-h-[70vh]"><About /></div>;
      case 'contato':
        return <div key="contato" className="py-20 bg-charchar text-white min-h-[70vh]"><Contact /></div>;
      default:
        return <Hero onTrainingClick={() => changeTab('treinos')} onStringingClick={() => changeTab('encordoamento')} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative bg-white overflow-x-hidden">
      <div className="fixed inset-0 pointer-events-none z-[10000]">
        {particles.map((p) => (
          <div
            key={p.id}
            className="tennis-particle animate-tennis-bounce"
            style={{ 
              left: p.x, 
              top: p.y
            } as React.CSSProperties}
          />
        ))}
      </div>

      <Navbar 
        activeTab={activeTab} 
        onTabChange={changeTab} 
        onOpenGMB={() => setIsGMBModalOpen(true)} 
      />
      
      <main className={`flex-grow pt-[80px] transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
        <Reveal key={activeTab} threshold={0}>
          {renderTabContent()}
        </Reveal>
      </main>

      <Footer />

      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-8 right-8 z-[50] p-4 bg-tealbrand text-white rounded-full shadow-2xl transition-all duration-500 hover:scale-110 active:scale-95 ${
          showScrollTop ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'
        }`}
        aria-label="Voltar ao topo"
      >
        <ChevronUp size={24} />
      </button>

      {isGMBModalOpen && (
        <GMBModal onClose={() => setIsGMBModalOpen(false)} />
      )}
    </div>
  );
};

export default App;

import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-charchar py-10 border-t border-white/5">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-white/30 text-sm">
          © {new Date().getFullYear()} Linkon Barcelos. Todos os direitos reservados.
        </div>
        <div className="text-white/40 text-[10px] font-bold uppercase tracking-[0.2em]">
          Técnica • Ritmo • Longevidade
        </div>
      </div>
    </footer>
  );
};

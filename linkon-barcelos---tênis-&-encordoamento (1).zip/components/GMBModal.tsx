import React from 'react';
import { X, Copy, CheckCircle, Code, ExternalLink, Info, Globe, Smartphone, MousePointer2 } from 'lucide-react';

interface GMBModalProps {
  onClose: () => void;
}

export const GMBModal: React.FC<GMBModalProps> = ({ onClose }) => {
  const [copied, setCopied] = React.useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const sections = [
    {
      id: 'framer-embed',
      title: 'Incorporar em HTML (Framer / Webflow)',
      isCode: true,
      content: `<!DOCTYPE html>
<html lang="pt-BR" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Linkon Barcelos | Tênis e Encordoamento</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              charchar: '#232323',
              tealbrand: '#0E7C7B',
              orangebrand: '#F39237',
              terracotta: '#E26D5C',
              tennisball: '#dcf000',
            }
          }
        }
      }
    </script>

    <!-- Fontes -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
      :root { scroll-behavior: smooth; }
      body { 
        font-family: 'Inter', sans-serif;
        cursor: url("data:image/svg+xml;utf8,<svg width='32' height='32' viewBox='0 0 32 32' fill='none' xmlns='http://www.w3.org/2000/svg'><ellipse cx='16' cy='10' rx='7' ry='9' stroke='%23232323' stroke-width='1.5'/><path d='M12 10H20M16 6V14' stroke='%23232323' stroke-width='0.5' stroke-opacity='0.4'/><path d='M16 19V24' stroke='%23232323' stroke-width='1.5'/><rect x='14.5' y='24' width='3' height='7' rx='0.5' fill='%23232323'/></svg>") 16 10, auto;
      }
    </style>

    <script type="importmap">
    {
      "imports": {
        "react-dom/": "https://esm.sh/react-dom@^19.2.4/",
        "react/": "https://esm.sh/react@^19.2.4/",
        "react": "https://esm.sh/react@^19.2.4",
        "lucide-react": "https://esm.sh/lucide-react@^0.563.0"
      }
    }
    </script>
</head>
<body class="bg-white text-slate-900">
    <div id="root"></div>
    <!-- Substitua pela URL do seu arquivo JS hospedado -->
    <script type="module" src="https://seu-dominio.com/bundle.js"></script>
</body>
</html>`
    },
    {
      id: 'gmb-desc',
      title: 'Descrição Google Meu Negócio',
      content: 'Linkon Barcelos - Treinador de Tênis e Encordoador em Campos do Jordão/SP. Ofereço treinos personalizados para todas as idades e níveis, focando em técnica, ritmo e longevidade. Especialista em encordoamento eletrônico de raquetes com consultoria técnica.'
    }
  ];

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-charchar/90 backdrop-blur-md">
      <div className="bg-white w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-xl shadow-2xl flex flex-col border border-tealbrand/10">
        
        {/* Header */}
        <div className="p-6 border-b flex justify-between items-center bg-slate-50">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-tealbrand rounded-lg flex items-center justify-center text-white shadow-lg shadow-tealbrand/20">
              <Globe size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-charchar leading-tight">Como Publicar no Framer</h2>
              <p className="text-xs text-slate-500 uppercase tracking-widest font-bold">Guia de Implantação Profissional</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X size={24} className="text-charchar" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-8 lg:p-12">
          {/* Passo a Passo Visual */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="p-6 bg-slate-50 rounded-xl border border-slate-100 relative">
              <div className="absolute -top-3 -left-3 w-8 h-8 bg-charchar text-white rounded-full flex items-center justify-center font-bold text-sm shadow-md">1</div>
              <Smartphone className="text-tealbrand mb-4" size={32} />
              <h4 className="font-bold text-sm uppercase mb-2">Hospedar</h4>
              <p className="text-xs text-slate-500 leading-relaxed">Hospede seu código React (JS) na <strong>Vercel</strong> ou <strong>GitHub Pages</strong> para obter um link público.</p>
            </div>
            <div className="p-6 bg-slate-50 rounded-xl border border-slate-100 relative">
              <div className="absolute -top-3 -left-3 w-8 h-8 bg-charchar text-white rounded-full flex items-center justify-center font-bold text-sm shadow-md">2</div>
              <Code className="text-orangebrand mb-4" size={32} />
              <h4 className="font-bold text-sm uppercase mb-2">Copiar HTML</h4>
              <p className="text-xs text-slate-500 leading-relaxed">Copie o shell HTML abaixo e cole no componente <strong>"Embed"</strong> (modo HTML) dentro do Framer.</p>
            </div>
            <div className="p-6 bg-slate-50 rounded-xl border border-slate-100 relative">
              <div className="absolute -top-3 -left-3 w-8 h-8 bg-charchar text-white rounded-full flex items-center justify-center font-bold text-sm shadow-md">3</div>
              <MousePointer2 className="text-terracotta mb-4" size={32} />
              <h4 className="font-bold text-sm uppercase mb-2">Conectar</h4>
              <p className="text-xs text-slate-500 leading-relaxed">No código colado, troque a URL do <code>script</code> pelo link da sua hospedagem do Passo 1.</p>
            </div>
          </div>

          {/* Seções de Cópia */}
          <div className="space-y-10">
            {sections.map((section) => (
              <div key={section.id} className="relative group">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-xs uppercase tracking-widest text-tealbrand flex items-center gap-2">
                    <Info size={14} />
                    {section.title}
                  </h3>
                  <button 
                    onClick={() => copyToClipboard(section.content, section.id)}
                    className={`flex items-center gap-2 px-5 py-2 rounded-full text-xs font-bold transition-all ${
                      copied === section.id 
                      ? 'bg-green-500 text-white' 
                      : 'bg-charchar text-white hover:bg-tealbrand'
                    }`}
                  >
                    {copied === section.id ? <CheckCircle size={14} /> : <Copy size={14} />}
                    {copied === section.id ? 'Código Copiado!' : 'Copiar para Framer'}
                  </button>
                </div>
                
                <div className={`rounded-xl border shadow-inner ${
                  section.isCode ? 'bg-charchar border-white/10' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div className={`p-6 text-sm leading-relaxed overflow-x-auto max-h-[300px] custom-scrollbar ${
                    section.isCode ? 'text-tealbrand font-mono whitespace-pre' : 'text-slate-700'
                  }`}>
                    {section.content}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Footer */}
        <div className="p-6 border-t bg-slate-50 flex items-center justify-between">
          <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
            Linkon Barcelos • Presença Digital Profissional
          </div>
          <div className="flex gap-4">
            <a href="https://framer.com" target="_blank" rel="noreferrer" className="text-[10px] text-slate-400 hover:text-charchar transition-colors underline">Documentação Framer Embed</a>
          </div>
        </div>
      </div>
      
      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.2); border-radius: 10px; }
      `}} />
    </div>
  );
};
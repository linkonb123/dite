import React from 'react';
import { Reveal } from './Reveal';

export const About: React.FC = () => {
  return (
    <div className="container mx-auto px-6 max-w-5xl">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <Reveal>
          <h2 className="text-tealbrand text-sm font-bold tracking-widest uppercase mb-4">Sobre mim</h2>
          <h3 className="text-3xl md:text-4xl font-bold mb-6 text-charchar tracking-tight">
            Linkon Barcelos
          </h3>
          
          <div className="space-y-4 text-slate-600 font-light leading-relaxed">
            <p>
              Sou apaixonado por tênis. Para mim, o tênis não é apenas sobre ganhar pontos ou jogos, mas sobre presença, postura e dar seu melhor. Dentro ou fora de quadra, dia após dia. Elevar a saúde e a qualidade de vida.
            </p>
            <p>
              Comecei a jogar com 9 anos e já sabia que vivia algo especial, só não sabia o tamanho do privilégio. Hoje, com 27, foco no estudo e treino para a melhora pequena e contínua que o tênis ensina, a que realmente te leva mais longe.
            </p>
            <p>
              Como treinador e encordoador, meu objetivo é fornecer as ferramentas — tanto físicas quanto técnicas — para que você jogue com confiança, prazer e longevidade, independentemente do seu nível atual.
            </p>
            <p>
              Em uma cidade turística, recebo com a mesma atenção o morador que busca rotina quanto o visitante que não abre mão de sua prática durante as férias. O tênis é o ponto comum de bem-estar.
            </p>
          </div>
        </Reveal>
        
        <Reveal delay={200} className="relative">
          <div className="aspect-[3/4] bg-slate-100 overflow-hidden rounded-sm border-r-8 border-b-8 border-tealbrand/10">
            <img 
              src="input_file_17.png" 
              alt="Linkon Barcelos em ação de saque" 
              className="w-full h-full object-cover"
              loading="lazy"
              decoding="async"
            />
          </div>
          
          {/* Bola de Tênis Pulsante Realista Aperfeiçoada */}
          <div className="absolute -bottom-6 -right-6 w-36 h-36 bg-tennisball rounded-full flex items-center justify-center shadow-[0_20px_50px_rgba(0,0,0,0.3)] border-[6px] border-white animate-pulse-soft overflow-hidden group">
            <div className="absolute inset-0 opacity-20 mix-blend-overlay pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/felt.png')]"></div>
            <div className="absolute inset-0 border-[4px] border-white/60 rounded-full scale-[1.3] -translate-x-[68%] translate-y-[10%] rotate-12"></div>
            <div className="absolute inset-0 border-[4px] border-white/60 rounded-full scale-[1.3] translate-x-[68%] -translate-y-[10%] -rotate-12"></div>
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/40 via-transparent to-black/20 pointer-events-none"></div>
            <div className="absolute inset-0 rounded-full shadow-[inset_0_4px_12px_rgba(255,255,255,0.8),inset_0_-4px_12px_rgba(0,0,0,0.15)]"></div>
            
            <div className="relative z-10 flex flex-col items-center justify-center text-center px-4">
              <span className="text-[12px] font-black leading-tight text-charchar uppercase tracking-tighter drop-shadow-md">
                Presença
              </span>
              <div className="h-[1px] w-8 bg-charchar/30 my-0.5"></div>
              <span className="text-[12px] font-black leading-tight text-charchar uppercase tracking-tighter drop-shadow-md">
                Técnica
              </span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out"></div>
          </div>
        </Reveal>
      </div>
    </div>
  );
};
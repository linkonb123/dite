
import React from 'react';
import { Users, User, ArrowRight } from 'lucide-react';
import { Reveal } from './Reveal';

export const Training: React.FC = () => {
  const phoneNumber = "5512988315404";

  const options = [
    {
      icon: <User className="text-tealbrand" size={32} />,
      title: "Treino Individual",
      desc: "Foco total na sua mecânica e ritmo. Ideal para quem busca correções técnicas profundas ou está iniciando do zero.",
      message: "Olá Linkon! Tenho interesse em saber mais sobre o Treino Individual."
    },
    {
      icon: <Users className="text-orangebrand" size={32} />,
      title: "Treino em Duplas",
      desc: "Aprenda e evolua ao lado de um parceiro. Treinos dinâmicos que favorecem a leitura de jogo e movimentação sincronizada.",
      message: "Olá Linkon! Tenho interesse em saber mais sobre o Treino em Duplas."
    }
  ];

  const handleCardClick = (message: string) => {
    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="container mx-auto px-6">
      <Reveal className="max-w-4xl mb-16">
        <h3 className="text-3xl md:text-4xl font-bold text-charchar leading-tight">
          Metodologia focada em <br /> técnica e longevidade.
        </h3>
      </Reveal>

      <div className="grid md:grid-cols-2 gap-8 max-w-5xl">
        {options.map((opt, idx) => (
          <Reveal key={idx} delay={idx * 150} threshold={0.1}>
            <button 
              onClick={() => handleCardClick(opt.message)}
              className="w-full text-left h-full bg-white p-10 border border-gray-100 hover:border-tealbrand/30 shadow-sm hover:shadow-xl transition-all group flex flex-col relative overflow-hidden rounded-sm"
            >
              <div className="mb-6 group-hover:scale-110 transition-transform duration-300">
                {opt.icon}
              </div>
              <h4 className="text-2xl font-bold mb-4 text-charchar group-hover:text-tealbrand transition-colors">
                {opt.title}
              </h4>
              <p className="text-slate-600 font-light leading-relaxed mb-10 text-lg">
                {opt.desc}
              </p>
              
              <div className="mt-auto flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-tealbrand opacity-0 group-hover:opacity-100 transition-opacity translate-x-[-10px] group-hover:translate-x-0 duration-300">
                Solicitar Horário <ArrowRight size={14} />
              </div>

              {/* Sutil detalhe visual no fundo ao hover */}
              <div className="absolute -right-6 -bottom-6 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                {/* Fix: Cast opt.icon to any to allow overriding 'size' prop in cloneElement */}
                {React.cloneElement(opt.icon as React.ReactElement<any>, { size: 160 })}
              </div>
            </button>
          </Reveal>
        ))}
      </div>
    </div>
  );
};

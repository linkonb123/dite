import React, { useState } from 'react';
import { MessageCircle, Instagram, MapPin } from 'lucide-react';
import { Reveal } from './Reveal';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    interest: 'Treinos Individuais',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const phoneNumber = "5512988315404";
    const text = `Olá Linkon!
Meu nome é: ${formData.name}
Tenho interesse em: ${formData.interest}
Mensagem: ${formData.message}`;
    
    const encodedText = encodeURIComponent(text);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedText}`;
    
    window.open(whatsappUrl, '_blank');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-2 gap-16">
        <Reveal>
          <h2 className="text-tealbrand text-sm font-bold tracking-widest uppercase mb-4">Vamos conversar</h2>
          <h3 className="text-4xl font-bold mb-8 text-white">
            Pronto para <br />entrar em quadra?
          </h3>
          
          <p className="text-white/80 font-light mb-12 text-lg leading-relaxed">
            Seja para seu primeiro treino, encordoar sua raquete ou tirar dúvidas, estou à disposição.
          </p>
          
          <div className="space-y-6">
            <a 
              href="https://wa.me/5512988315404" 
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 group"
            >
              <div className="w-12 h-12 rounded-full bg-tealbrand/20 flex items-center justify-center group-hover:bg-tealbrand/40 transition-all text-tealbrand">
                <div className="animate-pulse">
                  <MessageCircle size={24} />
                </div>
              </div>
              <div>
                <p className="text-xs text-white/50 font-bold uppercase tracking-wider">WhatsApp</p>
                <p className="text-lg">(12) 98831-5404</p>
              </div>
            </a>
            
            <a 
              href="https://instagram.com/_linkonbarcelos" 
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 group"
            >
              <div className="w-12 h-12 rounded-full bg-orangebrand/20 flex items-center justify-center group-hover:bg-orangebrand/40 transition-all text-orangebrand">
                <Instagram size={24} />
              </div>
              <div>
                <p className="text-xs text-white/50 font-bold uppercase tracking-wider">Instagram</p>
                <p className="text-lg">@_linkonbarcelos</p>
              </div>
            </a>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-terracotta/20 flex items-center justify-center text-terracotta">
                <MapPin size={24} />
              </div>
              <div>
                <p className="text-xs text-white/50 font-bold uppercase tracking-wider">Onde estou</p>
                <p className="text-lg">Campos do Jordão / SP</p>
              </div>
            </div>
          </div>
        </Reveal>
        
        <Reveal delay={300} className="bg-white/5 p-8 rounded-sm backdrop-blur-sm border border-white/10">
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/50 mb-2">Nome</label>
              <input 
                type="text" 
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Seu nome completo" 
                className="w-full bg-white/10 border border-white/10 p-3 text-white focus:outline-none focus:border-tealbrand transition-all" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/50 mb-2">Qual seu interesse?</label>
              <select 
                name="interest"
                value={formData.interest}
                onChange={handleChange}
                className="w-full bg-white/10 border border-white/10 p-3 text-white focus:outline-none focus:border-tealbrand transition-all appearance-none"
              >
                <option className="bg-charchar" value="Treinos Individuais">Treinos Individuais</option>
                <option className="bg-charchar" value="Treino em Dupla">Treino em Dupla</option>
                <option className="bg-charchar" value="Agendar Encordoamento">Agendar Encordoamento</option>
                <option className="bg-charchar" value="Dúvidas Gerais">Dúvidas Gerais</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/50 mb-2">Mensagem</label>
              <textarea 
                name="message"
                rows={4} 
                value={formData.message}
                onChange={handleChange}
                required
                placeholder="Como posso te ajudar?" 
                className="w-full bg-white/10 border border-white/10 p-3 text-white focus:outline-none focus:border-tealbrand transition-all"
              ></textarea>
            </div>
            <button 
              type="submit"
              className="w-full bg-tealbrand text-white font-bold py-4 rounded-sm hover:opacity-90 hover:shadow-lg transition-all active:scale-[0.99]"
            >
              Enviar Mensagem via WhatsApp
            </button>
          </form>
        </Reveal>
      </div>
    </div>
  );
};
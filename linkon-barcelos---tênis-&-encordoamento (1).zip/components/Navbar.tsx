import React, { useState, useEffect } from 'react';
import { Menu, X, Info } from 'lucide-react';
import { TabId } from '../App';

interface NavbarProps {
  onOpenGMB: () => void;
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenGMB, activeTab, onTabChange }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks: { name: string; id: TabId }[] = [
    { name: 'Início', id: 'inicio' },
    { name: 'Treinos', id: 'treinos' },
    { name: 'Encordoamento', id: 'encordoamento' },
    { name: 'Galeria', id: 'experiencia' },
    { name: 'Sobre', id: 'sobre' },
    { name: 'Contato', id: 'contato' },
  ];

  const handleLinkClick = (id: TabId) => {
    onTabChange(id);
    setIsMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className={`fixed w-full top-0 z-50 transition-all duration-500 bg-white shadow-sm py-4`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <button 
          onClick={() => handleLinkClick('inicio')} 
          className="font-bold text-xl tracking-tight transition-colors text-tealbrand"
        >
          LINKON <span className="font-light text-charchar">BARCELOS</span>
        </button>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-1">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`relative px-4 py-2 text-sm font-medium transition-all duration-300 group ${
                activeTab === link.id ? 'text-tealbrand' : 'text-slate-600 hover:text-tealbrand'
              }`}
            >
              {link.name}
              <span className={`absolute bottom-0 left-4 right-4 h-0.5 transition-transform duration-300 transform origin-left bg-tealbrand ${
                activeTab === link.id ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
              }`}></span>
            </button>
          ))}
          
          <div className="pl-4">
            <button 
              onClick={onOpenGMB}
              className="flex items-center gap-2 text-[10px] tracking-widest font-bold px-4 py-2 rounded-full transition-all duration-300 bg-charchar text-white hover:bg-tealbrand"
            >
              <Info size={12} />
              GMB INFO
            </button>
          </div>
        </div>

        {/* Mobile Toggle */}
        <div className="md:hidden flex items-center gap-4">
          <button 
            onClick={onOpenGMB}
            className="p-2 rounded-full bg-gray-100 text-tealbrand transition-colors"
          >
            <Info size={18} />
          </button>
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-charchar transition-colors"
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <div className={`md:hidden absolute top-full left-0 w-full bg-white shadow-2xl transition-all duration-300 ease-in-out ${isMenuOpen ? 'opacity-100 translate-y-0 visible' : 'opacity-0 -translate-y-4 invisible'}`}>
        <div className="flex flex-col p-6 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`text-lg text-left font-semibold p-3 rounded-lg transition-colors ${
                activeTab === link.id 
                  ? 'bg-tealbrand/10 text-tealbrand' 
                  : 'text-slate-800 hover:bg-slate-50'
              }`}
            >
              {link.name}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};
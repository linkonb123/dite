import React from 'react';
import { Settings, Info, Calendar, Zap, Activity, ShieldCheck, Ruler, Thermometer, AlertTriangle, Scale, Layers, Clock } from 'lucide-react';
import { Reveal } from './Reveal';

interface StringingProps {
  onContactClick?: () => void;
}

export const Stringing: React.FC<StringingProps> = ({ onContactClick }) => {
  const phoneNumber = "5512988315404";
  const message = "Olá Linkon! Gostaria de agendar o encordoamento da minha raquete. Quais são os horários disponíveis?";

  const handleWhatsAppClick = () => {
    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="container mx-auto px-6">
      {/* Hero Section of Stringing */}
      <div className="grid md:grid-cols-2 gap-16 items-center mb-24">
        <Reveal className="order-2 md:order-1">
          <div className="relative rounded-sm overflow-hidden shadow-2xl group aspect-[4/5] md:aspect-auto">
            <img 
              src="input_file_7.png" 
              alt="Detalhe técnico Wilson Blade 98" 
              className="w-full h-full md:h-[600px] object-cover transition-transform duration-700 group-hover:scale-105"
              loading="lazy"
              decoding="async"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charchar/60 to-transparent opacity-60"></div>
            <div className="absolute bottom-6 left-6 p-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-sm">
               <p className="text-[10px] text-white/70 uppercase tracking-widest font-bold">Consultoria Premium</p>
               <p className="text-white text-sm font-light italic">"Híbrido - Wilson Revolve Twist / Luxilon Adrenaline"</p>
            </div>
          </div>
        </Reveal>
        
        <Reveal className="order-1 md:order-2">
          <h3 className="text-3xl md:text-5xl font-bold mb-8 text-charchar leading-tight">
            A ciência do <br />motor da raquete.
          </h3>
          
          <div className="space-y-6 text-slate-600 font-light leading-relaxed mb-10">
            <p>
              O encordoamento é responsável por até <strong>70% da jogabilidade</strong> de uma raquete. É o único ponto de contato entre você e a bola. Tratar as cordas como um acessório secundário é o erro mais comum entre tenistas que buscam evolução.
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-4 mb-10">
            <div className="p-5 bg-slate-50 border-l-4 border-tealbrand flex gap-4 items-start">
              <Scale size={24} className="text-tealbrand shrink-0" />
              <div>
                <h4 className="font-bold text-charchar text-sm uppercase tracking-wider">Física da Tensão</h4>
                <p className="text-sm text-slate-500 mt-1">
                  <strong>Baixa Tensão (20-23kg / 44-51lbs):</strong> Mais potência (efeito trampolim) e conforto galopante. <br />
                  <strong>Alta Tensão (24-27kg / 53-60lbs):</strong> Mais controle e precisão direcional cirúrgica.
                </p>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleWhatsAppClick}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-10 py-5 bg-charchar text-white font-semibold rounded-sm hover:bg-tealbrand transition-all shadow-xl active:scale-95"
          >
            <div className="flex items-center gap-3">
              <Calendar size={20} />
              Agendar Encordoamento
            </div>
          </button>
        </Reveal>
      </div>

      {/* Seção de Materiais */}
      <div className="mb-24">
        <Reveal className="text-center mb-16">
          <h3 className="text-3xl font-bold text-charchar">Escolhendo sua Corda</h3>
        </Reveal>

        <div className="grid md:grid-cols-3 gap-8">
          <Reveal delay={100} className="bg-white p-8 border border-slate-100 shadow-sm hover:shadow-md transition-all">
            <div className="text-tealbrand mb-6"><Activity size={32} /></div>
            <h4 className="font-bold text-xl mb-4 text-charchar">Monofilamento</h4>
            <p className="text-slate-500 font-light text-sm leading-relaxed">
              Foco absoluto em <strong>controle e durabilidade</strong>. Projetado para quem busca spin e precisão em golpes de alta intensidade. Ideal para jogadores competitivos.
            </p>
          </Reveal>

          <Reveal delay={200} className="bg-white p-8 border border-slate-100 shadow-sm hover:shadow-md transition-all">
            <div className="text-orangebrand mb-6"><ShieldCheck size={32} /></div>
            <h4 className="font-bold text-xl mb-4 text-charchar">Multifilamento</h4>
            <p className="text-slate-500 font-light text-sm leading-relaxed">
              O máximo de <strong>conforto e potência</strong>. Sua estrutura elástica absorve vibrações, protegendo o braço e facilitando a saída de bola com menos esforço.
            </p>
          </Reveal>

          <Reveal delay={300} className="bg-white p-8 border border-slate-100 shadow-sm hover:shadow-md transition-all">
            <div className="text-terracotta mb-6"><Layers size={32} /></div>
            <h4 className="font-bold text-xl mb-4 text-charchar">Híbrido</h4>
            <p className="text-slate-500 font-light text-sm leading-relaxed">
              O <strong>melhor de dois mundos</strong>. Combina a firmeza do monofilamento com o toque do multifilamento ou tripa, permitindo um ajuste fino e personalizado.
            </p>
          </Reveal>
        </div>
      </div>

      {/* Recomendação Geral de Troca */}
      <Reveal className="mb-24 bg-tealbrand/5 border border-tealbrand/10 p-10 rounded-sm text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-tealbrand text-white mb-6">
          <Clock size={32} />
        </div>
        <h3 className="text-2xl font-bold text-charchar mb-4">Quando trocar seu encordoamento?</h3>
        <p className="max-w-3xl mx-auto text-slate-600 font-light leading-relaxed">
          Mesmo que a corda não estoure, ela perde suas propriedades elásticas (tensão) com o tempo e o uso. 
          Uma recomendação técnica segura é <strong>trocar a corda no ano o mesmo número de vezes que você joga por semana</strong>. 
          <br /><br />
          <span className="text-sm italic">Exemplo: Se você joga 3 vezes por semana, deve encordoar sua raquete pelo menos 3 vezes ao ano.</span>
        </p>
      </Reveal>

      {/* Checklist de Manutenção */}
      <div className="grid md:grid-cols-2 gap-12 items-stretch mb-24">
        <Reveal className="bg-slate-50 p-10 rounded-sm flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-8">
            <AlertTriangle className="text-orangebrand" size={28} />
            <h3 className="text-2xl font-bold text-charchar">Sinais de que está na hora de trocar sua corda.</h3>
          </div>
          <ul className="space-y-6">
            <li className="flex gap-4 items-start">
              <div className="w-6 h-6 rounded-full bg-orangebrand/10 text-orangebrand flex items-center justify-center shrink-0 mt-1 font-bold text-xs">1</div>
              <div>
                <h5 className="font-bold text-charchar text-sm uppercase">Perda de Tensão (Vibração)</h5>
                <p className="text-slate-500 text-sm">Cordas de poliéster perdem elasticidade e começam a vibrar de forma "seca", sobrecarregando o cotovelo.</p>
              </div>
            </li>
            <li className="flex gap-4 items-start">
              <div className="w-6 h-6 rounded-full bg-orangebrand/10 text-orangebrand flex items-center justify-center shrink-0 mt-1 font-bold text-xs">2</div>
              <div>
                <h5 className="font-bold text-charchar text-sm uppercase">Notching (Entalhes)</h5>
                <p className="text-slate-500 text-sm">Sulcos profundos onde as cordas se cruzam, impedindo que elas deslizem e gerem spin.</p>
              </div>
            </li>
            <li className="flex gap-4 items-start">
              <div className="w-6 h-6 rounded-full bg-orangebrand/10 text-orangebrand flex items-center justify-center shrink-0 mt-1 font-bold text-xs">3</div>
              <div>
                <h5 className="font-bold text-charchar text-sm uppercase">Desfiamento (Fraying)</h5>
                <p className="text-slate-500 text-sm">Sinal clássico de multifilamentos e tripa natural. Quando as fibras externas rompem, a falha catastrófica é iminente.</p>
              </div>
            </li>
          </ul>
        </Reveal>

        <Reveal delay={200} className="bg-charchar text-white p-10 rounded-sm relative overflow-hidden flex flex-col justify-center">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Thermometer size={120} />
          </div>
          <div className="relative z-10">
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-3 text-orangebrand">
              <Thermometer />
              Fator Térmico
            </h3>
            <p className="text-white/70 font-light leading-relaxed mb-6">
              As cordas são polímeros sensíveis. Deixar sua raquete no porta-malas em um dia quente de 35°C pode causar uma perda instantânea de até <strong>10% da tensão</strong> e alterar a estrutura molecular dos poliésteres, tornando-os quebradiços.
            </p>
            <div className="p-4 bg-white/5 border border-white/10 rounded-sm italic text-sm">
              Proteja sua raquete do calor extremo para manter a jogabilidade por mais tempo.
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
};
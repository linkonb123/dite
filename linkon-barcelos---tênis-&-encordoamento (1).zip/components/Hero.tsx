
import React from 'react';

interface HeroProps {
  onTrainingClick?: () => void;
  onStringingClick?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onTrainingClick, onStringingClick }) => {
  return (
    <div className="relative h-[calc(100vh-80px)] flex items-center overflow-hidden bg-charchar">
      {/* Background Image com Foto Real Otimizada */}
      <div className="absolute inset-0 z-0">
        <img 
          src="input_file_21.png" 
          alt="Quadra de tênis em Campos do Jordão" 
          className="w-full h-full object-cover opacity-30 scale-105"
          // Fix: Use camelCase fetchPriority instead of fetchpriority
          fetchPriority="high"
          decoding="sync"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charchar/40 via-charchar/60 to-charchar"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center md:text-left">
        <div className="max-w-4xl">
          <div className="inline-block px-4 py-1.5 bg-tealbrand/10 border border-tealbrand/20 rounded-full mb-6 animate-[fadeIn_1s_ease-out]">
            <span className="text-tealbrand text-xs font-bold tracking-[0.3em] uppercase">
              Campos do Jordão • Sp
            </span>
          </div>
          
          <h1 className="text-5xl md:text-8xl font-black text-white mb-4 tracking-tighter opacity-0 animate-[slideUp_1s_ease-out_0.2s_forwards]">
            LINKON <span className="text-white/20">BARCELOS</span>
          </h1>
          
          <div className="h-1 w-20 bg-orangebrand mb-8 opacity-0 animate-[slideUp_1s_ease-out_0.3s_forwards]"></div>
          
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-6 leading-tight opacity-0 animate-[slideUp_1s_ease-out_0.4s_forwards]">
            Treinos e Encordoamento — <br className="hidden md:block" />
            <span className="text-orangebrand font-light italic">Para quem quer começar, voltar ou evoluir no tênis.</span>
          </h2>
          
          <p className="text-lg md:text-xl text-white/60 mb-10 font-light leading-relaxed max-w-2xl opacity-0 animate-[slideUp_1s_ease-out_0.6s_forwards]">
            Treinos personalizados para todas as idades, com foco em técnica, ritmo e progresso no seu tempo. Atividades de caráter técnico e recreativo.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 opacity-0 animate-[slideUp_1s_ease-out_0.8s_forwards]">
            <button 
              onClick={onTrainingClick}
              className="px-10 py-4 bg-tealbrand text-white font-bold rounded-sm transition-all duration-300 ease-out text-center hover:scale-[1.02] hover:-translate-y-1 hover:shadow-[0_15px_30px_-10px_rgba(14,124,123,0.4)] hover:opacity-90 active:scale-95"
            >
              Agendar Treinamento
            </button>
            <button 
              onClick={onStringingClick}
              className="px-10 py-4 bg-white/5 border border-white/20 text-white font-bold rounded-sm transition-all duration-300 ease-out text-center hover:bg-white/10 hover:scale-[1.02] hover:-translate-y-1 hover:opacity-85 active:scale-95"
            >
              Agendar Encordoamento
            </button>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
      `}} />
    </div>
  );
};

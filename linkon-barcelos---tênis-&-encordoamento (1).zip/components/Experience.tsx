import React from 'react';
import { Reveal } from './Reveal';

export const Experience: React.FC = () => {
  const images = [
    "input_file_0.png",
    "input_file_1.png",
    "input_file_5.png",
    "input_file_6.png",
    "input_file_10.png",
    "input_file_11.png",
    "input_file_12.png",
    "input_file_13.png",
    "input_file_14.png",
    "input_file_15.png",
    "input_file_18.png",
    "input_file_19.png"
  ];

  return (
    <div className="container mx-auto px-6">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h2 className="text-tealbrand text-sm font-bold tracking-widest uppercase mb-4">Experiência</h2>
        <h3 className="text-3xl font-bold mb-4 text-charchar">O esporte na rotina.</h3>
        <p className="text-slate-600 font-light">Registros autênticos de treinos, vivências e o cuidado técnico especializado em Campos do Jordão.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {images.map((src, i) => (
          <Reveal key={i} delay={i * 100} threshold={0.2}>
            <div className="aspect-[3/4] overflow-hidden rounded-sm group relative bg-slate-100">
              <img 
                src={src} 
                alt={`Galeria registro ${i}`} 
                className={`w-full h-full object-cover transition-all duration-700 scale-100 group-hover:scale-110 ${i % 2 === 0 ? 'grayscale-0' : 'grayscale hover:grayscale-0'}`}
                loading="lazy"
                decoding="async"
              />
              <div className="absolute inset-0 bg-tealbrand/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none border-2 border-orangebrand/0 group-hover:border-orangebrand/50 m-2"></div>
            </div>
          </Reveal>
        ))}
      </div>
      
      <div className="mt-16 text-center italic text-terracotta font-light text-sm max-w-lg mx-auto leading-relaxed">
        "Cada imagem reflete o compromisso com a melhora contínua e a paixão pelo tênis em sua essência."
      </div>
    </div>
  );
};